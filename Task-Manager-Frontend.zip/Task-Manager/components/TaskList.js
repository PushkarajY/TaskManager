import React, { useState } from 'react';
import { useTasks } from '../src/contexts/TaskContext';
import TaskItem from './TaskItem';
import './TaskList.css';

function TaskList() {
  const { tasks } = useTasks();
  const [filter, setFilter] = useState('all'); // all, active, completed
  
  // Filter tasks based on the selected filter
  const filteredTasks = tasks.filter(task => {
    if (filter === 'active') return !task.completed;
    if (filter === 'completed') return task.completed;
    return true; // 'all' filter
  });
  
  // Get counts for the filter badges
  const counts = {
    all: tasks.length,
    active: tasks.filter(task => !task.completed).length,
    completed: tasks.filter(task => task.completed).length
  };

  return (
    <div className="task-list-container">
      <div className="task-list-header">
        <h2>My Tasks</h2>
        <div className="task-filters">
          <button 
            className={`filter-button ${filter === 'all' ? 'active' : ''}`}
            onClick={() => setFilter('all')}
          >
            All ({counts.all})
          </button>
          <button 
            className={`filter-button ${filter === 'active' ? 'active' : ''}`}
            onClick={() => setFilter('active')}
          >
            Active ({counts.active})
          </button>
          <button 
            className={`filter-button ${filter === 'completed' ? 'active' : ''}`}
            onClick={() => setFilter('completed')}
          >
            Completed ({counts.completed})
          </button>
        </div>
      </div>
      
      <div className="task-list">
        {filteredTasks.length === 0 ? (
          <div className="no-tasks-message">
            {filter === 'all' 
              ? 'No tasks yet. Add a task to get started!'
              : filter === 'active'
                ? 'No active tasks. Great job!'
                : 'No completed tasks yet.'}
          </div>
        ) : (
          filteredTasks.map(task => (
            <TaskItem key={task.id} task={task} />
          ))
        )}
      </div>
    </div>
  );
}

export default TaskList;