import React from 'react';
import { useTasks } from '../src/contexts/TaskContext';
import './TaskItem.css';

function TaskItem({ task }) {
  const { toggleTaskCompletion, deleteTask } = useTasks();
  
  // Format creation date
  const formatDate = (dateString) => {
    const options = { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };
  
  // Format time taken to complete
  const formatTimeTaken = (milliseconds) => {
    if (!milliseconds) return '';
    
    const seconds = Math.floor(milliseconds / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    
    if (days > 0) {
      return `${days}d ${hours % 24}h`;
    } else if (hours > 0) {
      return `${hours}h ${minutes % 60}m`;
    } else if (minutes > 0) {
      return `${minutes}m ${seconds % 60}s`;
    } else {
      return `${seconds}s`;
    }
  };

  return (
    <div className={`task-item ${task.completed ? 'completed' : ''}`}>
      <div className="task-item-header">
        <div className="task-checkbox-container">
          <input
            type="checkbox"
            checked={task.completed}
            onChange={() => toggleTaskCompletion(task.id)}
            id={`task-${task.id}`}
          />
          <label 
            htmlFor={`task-${task.id}`}
            className="task-title"
          >
            {task.title}
          </label>
        </div>
        <button 
          className="delete-task-button"
          onClick={() => deleteTask(task.id)}
          aria-label="Delete task"
        >
          ×
        </button>
      </div>
      
      {task.description && (
        <div className="task-description">{task.description}</div>
      )}
      
      <div className="task-meta">
        <div className="task-created">
          Created: {formatDate(task.createdAt)}
        </div>
        
        {task.completed && (
          <div className="task-completed">
            Completed: {formatDate(task.completedAt)}
            <span className="task-time-taken">
              Time taken: {formatTimeTaken(task.timeToComplete)}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}

export default TaskItem;