import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../src/contexts/AuthContext';
import { TaskProvider } from '../src/contexts/TaskContext';
import TaskList from '../src/components/TaskList';
import AddTaskForm from '../src/components/AddTaskForm';
import './TaskBoard.css';

function TaskBoard() {
  const { currentUser, logout } = useAuth();
  const navigate = useNavigate();
  
  const handleLogout = async () => {
    try {
      await logout();
      navigate('/login');
    } catch (error) {
      console.error('Failed to log out', error);
    }
  };

  return (
    <TaskProvider>
      <div className="task-board-container">
        <header className="board-header">
          <h1>Task Manager</h1>
          <div className="user-info">
            <span>Welcome, {currentUser.name || currentUser.email}</span>
            <button onClick={handleLogout} className="logout-button">Logout</button>
          </div>
        </header>
        
        <main className="board-content">
          <AddTaskForm />
          <TaskList />
        </main>
      </div>
    </TaskProvider>
  );
}

export default TaskBoard;