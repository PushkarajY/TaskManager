import React, { useContext, useState, createContext, useEffect } from 'react';

const AuthContext = createContext();

export function useAuth() {
  return useContext(AuthContext);
}

export function AuthProvider({ children }) {
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Check if user is logged in when component mounts
  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  // Sign up function
  const signup = (email, password, name) => {
    // In a real app, you would call your authentication API here
    const newUser = { id: Date.now().toString(), email, name };
    localStorage.setItem('user', JSON.stringify(newUser));
    setCurrentUser(newUser);
    return Promise.resolve(newUser);
  };

  // Login function
  const login = (email, password) => {
    // Simulate login - in a real app, you would validate against stored credentials
    // For demo purposes, we'll just check if email contains '@' and password length
    if (email.includes('@') && password.length >= 6) {
      const user = { id: Date.now().toString(), email, name: email.split('@')[0] };
      localStorage.setItem('user', JSON.stringify(user));
      setCurrentUser(user);
      return Promise.resolve(user);
    } else {
      return Promise.reject(new Error('Invalid credentials'));
    }
  };

  // Logout function
  const logout = () => {
    localStorage.removeItem('user');
    setCurrentUser(null);
    return Promise.resolve();
  };

  const value = {
    currentUser,
    signup,
    login,
    logout
  };

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  );
}