import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

const TaskContext = createContext();

export function useTasks() {
  return useContext(TaskContext);
}

export function TaskProvider({ children }) {
  const [tasks, setTasks] = useState([]);
  const { currentUser } = useAuth();
  
  // Load tasks from localStorage when the component mounts or user changes
  useEffect(() => {
    if (currentUser) {
      const storedTasks = localStorage.getItem(`tasks-${currentUser.id}`);
      if (storedTasks) {
        setTasks(JSON.parse(storedTasks));
      } else {
        setTasks([]);
      }
    }
  }, [currentUser]);

  // Save tasks to localStorage whenever they change
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(`tasks-${currentUser.id}`, JSON.stringify(tasks));
    }
  }, [tasks, currentUser]);

  // Add a new task
  const addTask = (title, description) => {
    const newTask = {
      id: Date.now().toString(),
      title,
      description,
      completed: false,
      createdAt: new Date().toISOString(),
      completedAt: null,
      timeToComplete: null
    };
    
    setTasks(prevTasks => [...prevTasks, newTask]);
  };

  // Toggle task completion status
  const toggleTaskCompletion = (taskId) => {
    setTasks(prevTasks => 
      prevTasks.map(task => {
        if (task.id === taskId) {
          const now = new Date();
          const isCompleting = !task.completed;
          
          // If completing, calculate time taken
          let timeToComplete = null;
          if (isCompleting) {
            const createdDate = new Date(task.createdAt);
            const diffInMs = now - createdDate;
            timeToComplete = diffInMs;
          }
          
          return {
            ...task,
            completed: isCompleting,
            completedAt: isCompleting ? now.toISOString() : null,
            timeToComplete: isCompleting ? timeToComplete : null
          };
        }
        return task;
      })
    );
  };

  // Delete a task
  const deleteTask = (taskId) => {
    setTasks(prevTasks => prevTasks.filter(task => task.id !== taskId));
  };

  const value = {
    tasks,
    addTask,
    toggleTaskCompletion,
    deleteTask
  };

  return (
    <TaskContext.Provider value={value}>
      {children}
    </TaskContext.Provider>
  );
}