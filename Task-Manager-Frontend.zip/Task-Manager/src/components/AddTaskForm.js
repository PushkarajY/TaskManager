import React, { useState } from 'react';
import { useTasks } from '../contexts/TaskContext';
import './AddTaskForm.css';

function AddTaskForm() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isExpanded, setIsExpanded] = useState(false);
  const { addTask } = useTasks();

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!title.trim()) return;
    
    addTask(title, description);
    setTitle('');
    setDescription('');
    setIsExpanded(false);
  };

  return (
    <div className="add-task-container">
      <h2>Add New Task</h2>
      <form onSubmit={handleSubmit} className="add-task-form">
        <div className="form-group">
          <input
            type="text"
            placeholder="Task title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            onFocus={() => setIsExpanded(true)}
            required
          />
        </div>
        
        {isExpanded && (
          <div className="form-group">
            <textarea
              placeholder="Task description (optional)"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows="3"
            />
          </div>
        )}
        
        <div className="form-actions">
          {isExpanded && (
            <button 
              type="button" 
              className="cancel-button"
              onClick={() => {
                setIsExpanded(false);
                setTitle('');
                setDescription('');
              }}
            >
              Cancel
            </button>
          )}
          <button type="submit" className="add-button">
            Add Task
          </button>
        </div>
      </form>
    </div>
  );
}

export default AddTaskForm;